import React from 'react'
import { render } from 'react-dom'
import imageData from './image-data'

const Image = (props) => {
  const {title, alt, src} = props.image;
  return <div className='img-box'>
    <img title={title} alt={alt} src={src}></img>
  </div>;
}

const Gallery = (props) => {
  console.log(props.images);
  return <section className='content'>
    {props.images.map((image, i) => {
      return <Image image={image}></Image>;
      }) }
  </section>;
}

 render(<Gallery images={imageData} />, document.getElementById('root'))
